//
//  Apr11AppDelegate.h
//  Appr18
//
//  Created by Joe Gabela on 4/14/13.
//  Copyright (c) 2013 Joe Gabela. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Apr18AppDelegate : UIResponder <UIApplicationDelegate>
{
	UIWindow *_window;
}

@property (strong, nonatomic) UIWindow *window;

@end
